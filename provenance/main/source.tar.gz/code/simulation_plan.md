# Approved simulation study: main risk-estimation results

Approved by the author on 26 September 2026. This replaces the older active
plan; historical experiments remain in their report directories. The author
also authorized three separate jobs submitted through `ssh unity`.

## Common design

- Gaussian feature rows with AR(1) covariance `Sigma[j,k] = 0.5**abs(j-k)`.
- Noise variance 1. A fixed direction has its first `min(10,d)` coordinates
  equal to one. Normalize beta so `beta.T @ Sigma @ beta = 4`.
- Sample-size grid `{128,256,512}`; the conditional study uses the middle size.
- 3,000 repetitions for every study setting. The conditional study fixes
  20 fitted summaries per setting and uses 3,000 independent complementary
  draws per summary, with uncertainty over the 20 independent summaries.
- Master seed `2026092601`; deterministic SHA256-keyed independent feature,
  error and sketch streams. Methods share each fitted model. Sketches share
  data, and row subsets are nested across sketch sizes.
- Generate the linear-model data and fit the regressions. Do not generate
  simulation outcomes from the scalar risk or chi-square laws.
- Target the same fit's exact response prediction risk
  `R = 1 + (beta_hat-beta).T @ Sigma @ (beta_hat-beta)`.
- Pointwise 95% Monte Carlo intervals. Preserve failures; no redraws,
  trimming, adaptive repetition counts or selected follow-up cells.

## 1. Conditional complementary risk estimation

`n=256`, `m=128`, `d in {64,192,320}`; row and raw dense Gaussian sketches.
Features and errors are Gaussian. Six settings, 20 frozen summaries each,
3,000 complementary draws each: 120 fitted summaries and 360,000 draws.

Freeze the sketch, row-space design and noise; regenerate every feature and
noise coordinate in the complementary subspace. Fit raw compressed least
squares for `d<m` and the minimum-norm solution for `d>m`. The estimate uses
only the complementary residual in both regimes. The full residual contains
an additional fixed row-space component when `d<m`.

Report mean estimate/risk, conditional variance relative to `2/(n-m)`, and
95% risk-interval coverage. Student t intervals aggregate the 20 independent
frozen summaries. The chi-square law supplies theoretical interval endpoints,
not the simulated observations. Save frozen summaries and all draw records.

## 2. Accuracy of the corrected risk estimate

`n in {128,256,512}` and `(d/n,m/n) in {(.25,.50),(.50,.75)}`. Use row and
trace-normalized weighted Haar sketches (alternating weights 1 and 2), with
Gaussian and Rademacher errors. There are 24 settings and 72,000 fitted models.

Compare corrected, population-sensitivity corrected and GCV estimates.
Include the complementary estimate in Gaussian-error summaries. Report MAE
versus sample size; retain bias, RMSE, scaled MAE and paired absolute-error
comparisons in the result archive. The main table uses the common size n=512.

## 3. Tight-frame MSE threshold

Use the common sample-size grid, `d/n in {.25,.50}`, row sketches and Gaussian
errors. Set `m = round(n*(rho_star + delta))` for
`delta in {-.08,-.04,0,.04,.08}`, where `rho_star=3*gamma/(1+2*gamma)`.
The 30 settings have 90,000 fitted-model evaluations, based on 18,000 datasets.
The exact MSE theorem permits the common AR(1) covariance.

Plot empirical MSE(corrected)/MSE(complementary) with paired log-delta
intervals. Retain the green "Exact ratio" curve, black dashed rho_star line,
and orange dotted rho_n^exact line. The exact continuous root differs from
the first-order finite-n expansion. Monte Carlo comparisons assess agreement
with the ratio and ordering away from equality; they do not resolve the small
O(1/n) threshold displacement.

The six central row/Gaussian settings reuse the same data and sketches as the
accuracy study. Their 18,000 repeated fit evaluations are paired reuse,
not additional independent evidence. The two jobs together evaluate 144,000
unique joint-study fits (162,000 total fit evaluations).

## Execution and outputs

Source: `code/main_studies/{common,conditional,accuracy,threshold}.py`.
Submit one separate Slurm job per study using the corresponding `.sbatch` file.
Each job requests six CPUs, 16 GB, four hours, partition `stat`; BLAS uses one
thread per worker. All jobs use the same pinned existing Unity Python environment.
Results are retained under `reports/main-studies-20260926/` after download,
with the source snapshot, Slurm records, metadata and replicate-level data.

Replace Section 6 with three study figures and one accuracy table. Remove the
standalone isotropic benchmark, runtime experiment, broad duplicate comparison
and separate Rademacher subsection. Update the introduction and runtime
cross-reference accordingly. Keep their historical reports intact.
